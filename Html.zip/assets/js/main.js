

$(document).ready(function() {

    $('.btn-menu').on('click', function() {
        $('.sidebar').toggleClass('active');
    });

});


$(document).ready(function() {
    $('#grid').click(function(event){event.preventDefault();$('#products .item').addClass('masonry-list-item');});
    $('#list').click(function(event){event.preventDefault();$('#products .item').removeClass('masonry-list-item');$('#products .item').addClass('grid-group-item');});
});

$('.btn-list-box a').on('click', function(){
    $(this).siblings().removeClass('active')
    $(this).addClass('active');
})

$('#grid').click(function(){
    $('.masonry').addClass('masonry-list-view');
});

$('#list').click(function(){
    $('.masonry').removeClass('masonry-list-view');
});